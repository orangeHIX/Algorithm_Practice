package com.creaty.javaclass.student_managment.RPC.test;

/**
 * Created by hyx on 2015/12/23.
 */
public interface SayHelloService {

    String sayHello(String helloArg);

}
